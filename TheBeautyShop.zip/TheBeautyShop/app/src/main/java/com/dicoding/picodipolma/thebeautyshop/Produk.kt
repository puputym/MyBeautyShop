package com.dicoding.picodipolma.thebeautyshop

data class Produk (
    var name : String = "",
    var harga : String ="",
    var detail : String = "",
    var photo : Int = 0

)